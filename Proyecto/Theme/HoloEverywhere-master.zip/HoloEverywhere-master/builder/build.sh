#!/bin/bash
java -jar builder.jar styles.xml ../library/res/values/styles.xml
java -jar builder.jar styles-v14.xml ../library/res/values-v14/styles.xml
