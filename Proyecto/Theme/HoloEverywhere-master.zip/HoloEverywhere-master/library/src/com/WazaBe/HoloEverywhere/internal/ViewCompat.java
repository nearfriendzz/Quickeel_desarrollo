package com.WazaBe.HoloEverywhere.internal;

public class ViewCompat extends android.support.v4.view.ViewCompat {

	private ViewCompat() {

	}

}
