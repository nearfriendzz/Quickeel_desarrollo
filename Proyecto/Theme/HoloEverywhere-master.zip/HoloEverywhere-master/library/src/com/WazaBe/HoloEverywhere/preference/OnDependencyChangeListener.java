package com.WazaBe.HoloEverywhere.preference;

interface OnDependencyChangeListener {
	void onDependencyChanged(Preference dependency, boolean disablesDependent);
}